// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class hollowPurple extends Actor
{

    /**
     * Act - do whatever the hollowPurple wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        eatCrab();
        randomDirection();
    }

    /**
     * 
     */
    public void randomDirection()
    {
        if (Greenfoot.isKeyDown("right")) {
            move(5);
        }
        else if (Greenfoot.isKeyDown("left")) {
            move(-5);
        }
        else {
            turn(6);
            move(6);
        }
    }

    /**
     * 
     */
    public void eatCrab()
    {
        Actor crab = getOneIntersectingObject(Crab.class);
        if (crab != null) {
            World world = getWorld();
            world.removeObject(crab);
            Greenfoot.playSound("gomenAmanai.mp3");
            World gameLostWorld =  new  GameLostWorld();
            Greenfoot.setWorld(gameLostWorld);
        }
    }
}

// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class GameWonBackground extends World
{

    /**
     * Constructor for objects of class GameWonBackground.
     */
    public GameWonBackground()
    {
        super(560, 560, 1);
        Greenfoot.playSound("yowaiMo.mp3");
        showTextWithFont("You win!", 85, 300);
    }

    /**
     * 
     */
    public void showTextWithFont(String message, int x, int y)
    {
        GreenfootImage bg = getBackground();
        Font font =  new Font(100);
        bg.setFont(font);
        bg.setColor(Color.BLACK);
        bg.drawString(message, x, y);
    }
}

// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Lobster extends Actor
{

    /**
     * 
     */
    public Lobster()
    {
        turn(Greenfoot.getRandomNumber(360));
    }

    /**
     * Act - do whatever the Lobster wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveAround();
        eatCrab();
        killWorm();
        randomHollowPurple();
    }

    /**
     * 
     */
    public void moveAround()
    {
        move(4);
        if (Greenfoot.getRandomNumber(10) == 1) {
            turn(Greenfoot.getRandomNumber(90) - 45);
        }
        if (isAtEdge()) {
            turn(180);
        }
    }

    /**
     * 
     */
    public void eatCrab()
    {
        Actor crab = getOneIntersectingObject(Crab.class);
        if (crab != null) {
            World world = getWorld();
            world.removeObject(crab);
            Greenfoot.playSound("gomenAmanai.mp3");
            World gameLostWorld =  new  GameLostWorld();
            Greenfoot.setWorld(gameLostWorld);
        }
    }

    /**
     * 
     */
    public void killWorm()
    {
        Actor worm = getOneIntersectingObject(Worm.class);
        if ((worm != null) && (Greenfoot.getRandomNumber(1000) > 990)) {
            World world = getWorld();
            Lobster lobster1 =  new  Lobster();
            world.addObject(lobster1, worm.getX(), worm.getY());
            world.removeObject(worm);
        }
    }

    /**
     * 
     */
    public void randomHollowPurple()
    {
        Actor hollowPurple =  new  hollowPurple();
        World world = getWorld();
        if (Greenfoot.getRandomNumber(10000) >= 9990) {
            Greenfoot.playSound("hollowPurpleShort.mp3");
            world.addObject(hollowPurple, getX(), getY());
        }
    }
}
